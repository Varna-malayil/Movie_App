import "./app.css";
import MovieCard from "./MovieCard";
import search from "../src/assets/search.png";
import { useEffect, useState } from "react";

function App() {
  const [movies, setMovies] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const api_url = "http://www.omdbapi.com?apikey=7ac741d8";
  const movieSearch = async (title) => {
    if (title.trim() === "") {
      setMovies([]);
      return;
    }

    const response = await fetch(`${api_url}&s=${title}`);
    const data = await response.json();
    if (data.Response === "False") {
      setMovies([]);
    } else {
      setMovies(data.Search || []);
    }
  };

  useEffect(() => {
    movieSearch("race");
  }, []);

  return (
    <div className="flex justify-center items-center flex-col p-16 sm:p-8 md:p-4">
      <h1 className="text-5xl  mb-12 font-bold bg-[linear-gradient(90deg,_#3f7fff_10%,_transparent_100%)] leading-normal bg-clip-text text-transparent">
        Movie World
      </h1>

      <div className="flex justify-center items-center mt-8 mb-8 w-full sm:w-11/12 md:w-3/4 px-7 py-6 sm:px-4 sm:py-4 rounded-3xl bg-[var(--color-2)] shadow-lg sm:shadow-xl md:shadow-[0px_20px_20px_-8px_rgba(0,0,0,0.2)]">
        <input
          className="flex-1 text-xl sm:text-lg font-[var(--font-raleway)] font-medium pr-2 outline-none text-black bg-[var(--color-2)]"
          value={searchTerm}
          onChange={(event) => {
            setSearchTerm(event.target.value);
          }}
          placeholder="Search for movies"
        />
        <img
          src={search}
          className="w-8 h-8 cursor-pointer"
          onClick={() => {
            movieSearch(searchTerm);
          }}
          alt="search"
        />
      </div>

      {movies.length > 0 ? (
        <div className="w-full mt-12 flex justify-center items-center flex-wrap gap-4">
          {movies.map((movie) => (
            <MovieCard key={movie.id} state={movie} />
          ))}
        </div>
      ) : (
        <div className="w-full mt-12 flex justify-center items-center">
          <h2 className="font-bold text-xl sm:text-lg text-[var(--color-4)]">
            Movies not found
          </h2>
        </div>
      )}
    </div>
  );
}

export default App;
